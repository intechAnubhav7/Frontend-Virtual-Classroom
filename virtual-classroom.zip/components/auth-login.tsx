"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { User, Lock, Wifi } from "lucide-react"

interface AuthLoginProps {
  onLogin: (userType: "teacher" | "student", userData?: any) => void
}

export function AuthLogin({ onLogin }: AuthLoginProps) {
  const [userType, setUserType] = useState<"teacher" | "student">("student")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [classCode, setClassCode] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async () => {
    setIsLoading(true)

    // Simulate authentication delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (userType === "teacher") {
      // Simple teacher authentication
      if (email && password) {
        onLogin("teacher", {
          name: "Prof. Sarah Johnson",
          email: email,
          id: "teacher_1",
        })
      }
    } else {
      // Simple student join with class code
      if (classCode) {
        onLogin("student", {
          name: `Student_${Math.floor(Math.random() * 1000)}`,
          classCode: classCode,
          id: `student_${Math.floor(Math.random() * 10000)}`,
        })
      }
    }

    setIsLoading(false)
  }

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 min-h-screen flex flex-col justify-center">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold text-balance">Virtual Classroom</h1>
        <p className="text-sm text-muted-foreground">Low-bandwidth education platform</p>
        <div className="flex items-center justify-center gap-2">
          <Wifi className="h-4 w-4 text-emerald-500" />
          <span className="text-xs text-emerald-600">Optimized for slow connections</span>
        </div>
      </div>

      {/* User Type Selection */}
      <div className="flex gap-2">
        <Button
          variant={userType === "student" ? "default" : "outline"}
          onClick={() => setUserType("student")}
          className="flex-1"
        >
          Join as Student
        </Button>
        <Button
          variant={userType === "teacher" ? "default" : "outline"}
          onClick={() => setUserType("teacher")}
          className="flex-1"
        >
          Teacher Login
        </Button>
      </div>

      {/* Login Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            {userType === "teacher" ? <Lock className="h-5 w-5" /> : <User className="h-5 w-5" />}
            {userType === "teacher" ? "Teacher Login" : "Join Class"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {userType === "teacher" ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="teacher@school.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </>
          ) : (
            <div className="space-y-2">
              <Label htmlFor="classCode">Class Code</Label>
              <Input
                id="classCode"
                placeholder="Enter 6-digit class code"
                value={classCode}
                onChange={(e) => setClassCode(e.target.value.toUpperCase())}
                maxLength={6}
                className="text-center text-lg font-mono"
              />
              <p className="text-xs text-muted-foreground text-center">
                Get the code from your teacher or scan QR code
              </p>
            </div>
          )}

          <Button
            onClick={handleLogin}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            disabled={isLoading || (userType === "teacher" ? !email || !password : !classCode)}
          >
            {isLoading ? "Connecting..." : userType === "teacher" ? "Login" : "Join Class"}
          </Button>

          {userType === "student" && (
            <div className="text-center">
              <Badge variant="secondary" className="text-xs">
                Demo Code: MATH01
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Features */}
      <div className="space-y-2">
        <h3 className="text-sm font-medium text-center">Platform Features</h3>
        <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
          <div className="text-center">✓ Audio-first learning</div>
          <div className="text-center">✓ Offline downloads</div>
          <div className="text-center">✓ Low data usage</div>
          <div className="text-center">✓ Mobile optimized</div>
        </div>
      </div>
    </div>
  )
}
