"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Upload, Play, Pause, Users, QrCode, Mic, MicOff, Share2, Download, BarChart3 } from "lucide-react"

interface TeacherDashboardProps {
  userData: any
  onLogout: () => void
}

export function TeacherDashboard({ userData, onLogout }: TeacherDashboardProps) {
  const [activeTab, setActiveTab] = useState<"setup" | "live" | "analytics">("setup")
  const [isRecording, setIsRecording] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [classTitle, setClassTitle] = useState("Introduction to Mathematics")
  const [uploadedSlides, setUploadedSlides] = useState<File[]>([])

  const classCode = "MATH01"
  const studentsOnline = 24

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setUploadedSlides((prev) => [...prev, ...files])
  }

  const startClass = () => {
    setActiveTab("live")
    setIsRecording(true)
  }

  if (activeTab === "setup") {
    return (
      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold">Teacher Dashboard</h1>
            <p className="text-sm text-muted-foreground">Welcome, {userData.name}</p>
          </div>
          <Button variant="outline" size="sm" onClick={onLogout}>
            Logout
          </Button>
        </div>

        {/* Class Setup */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Class Setup</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Class Title</Label>
              <Input id="title" value={classTitle} onChange={(e) => setClassTitle(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label>Upload Slides</Label>
              <div className="border-2 border-dashed border-muted rounded-lg p-4 text-center">
                <input
                  type="file"
                  multiple
                  accept=".pdf,.ppt,.pptx,.jpg,.png"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="slide-upload"
                />
                <label htmlFor="slide-upload" className="cursor-pointer">
                  <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">Click to upload slides</p>
                  <p className="text-xs text-muted-foreground">PDF, PPT, or images</p>
                </label>
              </div>
            </div>

            {uploadedSlides.length > 0 && (
              <div className="space-y-2">
                <Label>Uploaded Files ({uploadedSlides.length})</Label>
                {uploadedSlides.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm truncate">{file.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {(file.size / 1024 / 1024).toFixed(1)} MB
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Class Code */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <QrCode className="h-4 w-4" />
              Student Access
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-center">
              <div className="text-2xl font-mono font-bold bg-muted p-3 rounded">{classCode}</div>
              <p className="text-xs text-muted-foreground mt-1">Share this code with students</p>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                <Share2 className="h-3 w-3 mr-1" />
                Share Link
              </Button>
              <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                <QrCode className="h-3 w-3 mr-1" />
                QR Code
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Start Class */}
        <Button
          onClick={startClass}
          className="w-full bg-emerald-600 hover:bg-emerald-700"
          disabled={uploadedSlides.length === 0}
        >
          <Play className="h-4 w-4 mr-2" />
          Start Live Class
        </Button>
      </div>
    )
  }

  if (activeTab === "live") {
    return (
      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Live Class Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold">{classTitle}</h1>
            <div className="flex items-center gap-2">
              <Badge variant="destructive" className="text-xs">
                ● LIVE
              </Badge>
              <span className="text-sm text-muted-foreground">
                <Users className="h-3 w-3 inline mr-1" />
                {studentsOnline} students
              </span>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => setActiveTab("setup")}>
            End Class
          </Button>
        </div>

        {/* Recording Controls */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant={isRecording ? "destructive" : "default"}
                  onClick={() => setIsRecording(!isRecording)}
                >
                  {isRecording ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button size="sm" variant={isMuted ? "destructive" : "outline"} onClick={() => setIsMuted(!isMuted)}>
                  {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </Button>
              </div>
              <div className="text-sm text-muted-foreground">
                {isRecording ? "Recording: 05:23" : "Ready to record"}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Slide Control */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Slide Control</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="bg-muted rounded-lg p-4 min-h-[100px] flex items-center justify-center">
              <div className="text-center">
                <h3 className="font-semibold">Slide 1: Welcome</h3>
                <p className="text-sm text-muted-foreground">Introduction to Mathematics</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                Previous
              </Button>
              <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                Next Slide
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-3 gap-2">
          <Button size="sm" variant="outline" className="flex flex-col gap-1 h-auto py-2 bg-transparent">
            <BarChart3 className="h-4 w-4" />
            <span className="text-xs">Poll</span>
          </Button>
          <Button size="sm" variant="outline" className="flex flex-col gap-1 h-auto py-2 bg-transparent">
            <Download className="h-4 w-4" />
            <span className="text-xs">Share</span>
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setActiveTab("analytics")}
            className="flex flex-col gap-1 h-auto py-2"
          >
            <Users className="h-4 w-4" />
            <span className="text-xs">Students</span>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-md mx-auto p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold">Class Analytics</h1>
        <Button variant="outline" size="sm" onClick={() => setActiveTab("live")}>
          Back to Live
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Student Engagement</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span className="text-sm">Total Students</span>
            <span className="font-semibold">{studentsOnline}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Active Now</span>
            <span className="font-semibold text-emerald-600">{studentsOnline - 2}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Average Attendance</span>
            <span className="font-semibold">92%</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
