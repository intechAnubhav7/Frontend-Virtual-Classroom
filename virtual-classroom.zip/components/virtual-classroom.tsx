"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { AuthLogin } from "./auth-login"
import { TeacherDashboard } from "./teacher-dashboard"
import {
  Play,
  Pause,
  Volume2,
  Download,
  MessageCircle,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Wifi,
  WifiOff,
  Users,
  BookOpen,
  Send,
} from "lucide-react"

export function VirtualClassroom() {
  const [user, setUser] = useState<{ type: "teacher" | "student" | null; data?: any }>({ type: null })
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentSlide, setCurrentSlide] = useState(1)
  const [activeTab, setActiveTab] = useState<"classroom" | "materials" | "chat" | "polls">("classroom")
  const [connectionStatus, setConnectionStatus] = useState<"good" | "poor" | "offline">("good")
  const [chatMessage, setChatMessage] = useState("")

  const handleLogin = (userType: "teacher" | "student", userData?: any) => {
    setUser({ type: userType, data: userData })
  }

  const handleLogout = () => {
    setUser({ type: null })
  }

  if (!user.type) {
    return <AuthLogin onLogin={handleLogin} />
  }

  if (user.type === "teacher") {
    return <TeacherDashboard userData={user.data} onLogout={handleLogout} />
  }

  const totalSlides = 8
  const classTitle = "Introduction to Mathematics"
  const teacherName = "Prof. Sarah Johnson"

  const slides = [
    { id: 1, title: "Welcome to Mathematics", content: "Basic concepts and fundamentals" },
    { id: 2, title: "Numbers and Operations", content: "Addition, subtraction, multiplication" },
    { id: 3, title: "Fractions", content: "Understanding parts of a whole" },
    { id: 4, title: "Geometry Basics", content: "Shapes and their properties" },
    { id: 5, title: "Measurement", content: "Length, weight, and volume" },
    { id: 6, title: "Data and Graphs", content: "Reading and creating charts" },
    { id: 7, title: "Problem Solving", content: "Step-by-step approaches" },
    { id: 8, title: "Review and Practice", content: "Key concepts summary" },
  ]

  const chatMessages = [
    {
      id: 1,
      sender: "Teacher",
      message: "Welcome everyone! Let's start today's lesson.",
      time: "10:00 AM",
      isTeacher: true,
    },
    { id: 2, sender: "Raj", message: "Good morning ma'am", time: "10:01 AM", isTeacher: false },
    { id: 3, sender: "Priya", message: "Can you repeat the last point?", time: "10:15 AM", isTeacher: false },
    { id: 4, sender: "Teacher", message: "Of course! Let me explain again...", time: "10:16 AM", isTeacher: true },
  ]

  const pollQuestion = {
    question: "What is 2 + 3?",
    options: ["4", "5", "6", "7"],
    correctAnswer: 1,
  }

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  const nextSlide = () => {
    if (currentSlide < totalSlides) {
      setCurrentSlide(currentSlide + 1)
    }
  }

  const prevSlide = () => {
    if (currentSlide > 1) {
      setCurrentSlide(currentSlide - 1)
    }
  }

  const sendMessage = () => {
    if (chatMessage.trim()) {
      // In a real app, this would send the message
      setChatMessage("")
    }
  }

  const getConnectionIcon = () => {
    switch (connectionStatus) {
      case "good":
        return <Wifi className="h-4 w-4 text-accent" />
      case "poor":
        return <Wifi className="h-4 w-4 text-yellow-500" />
      case "offline":
        return <WifiOff className="h-4 w-4 text-destructive" />
    }
  }

  const getConnectionText = () => {
    switch (connectionStatus) {
      case "good":
        return "Good Connection"
      case "poor":
        return "Slow Connection"
      case "offline":
        return "Offline Mode"
    }
  }

  if (activeTab === "classroom") {
    return (
      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-xl font-bold text-balance">{classTitle}</h1>
          <p className="text-sm text-muted-foreground">with {teacherName}</p>
          <div className="flex items-center justify-center gap-2">
            {getConnectionIcon()}
            <span className="text-xs">{getConnectionText()}</span>
          </div>
        </div>

        {/* Audio Player */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Button size="sm" onClick={handlePlayPause} className="bg-primary hover:bg-primary/90">
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Volume2 className="h-4 w-4 text-muted-foreground" />
              </div>
              <Button size="sm" variant="outline" className="gap-1 bg-transparent">
                <Download className="h-3 w-3" />
                <span className="text-xs">Save</span>
              </Button>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-primary h-2 rounded-full w-1/3"></div>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>5:23</span>
              <span>15:45</span>
            </div>
          </CardContent>
        </Card>

        {/* Current Slide */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">
                Slide {currentSlide} of {totalSlides}
              </CardTitle>
              <Badge variant="secondary" className="text-xs">
                {Math.round((currentSlide / totalSlides) * 100)}%
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="bg-muted rounded-lg p-4 min-h-[120px] flex flex-col justify-center">
              <h3 className="font-semibold text-sm mb-2">{slides[currentSlide - 1]?.title}</h3>
              <p className="text-xs text-muted-foreground">{slides[currentSlide - 1]?.content}</p>
            </div>
            <div className="flex justify-between">
              <Button size="sm" variant="outline" onClick={prevSlide} disabled={currentSlide === 1}>
                <ChevronLeft className="h-3 w-3" />
                Prev
              </Button>
              <Button size="sm" variant="outline" onClick={nextSlide} disabled={currentSlide === totalSlides}>
                Next
                <ChevronRight className="h-3 w-3" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-4 gap-2">
          <Button
            size="sm"
            variant={activeTab === "classroom" ? "default" : "outline"}
            onClick={() => setActiveTab("classroom")}
            className="flex flex-col gap-1 h-auto py-2"
          >
            <BookOpen className="h-4 w-4" />
            <span className="text-xs">Class</span>
          </Button>
          <Button
            size="sm"
            variant={activeTab === "materials" ? "default" : "outline"}
            onClick={() => setActiveTab("materials")}
            className="flex flex-col gap-1 h-auto py-2"
          >
            <Download className="h-4 w-4" />
            <span className="text-xs">Materials</span>
          </Button>
          <Button
            size="sm"
            variant={activeTab === "chat" ? "default" : "outline"}
            onClick={() => setActiveTab("chat")}
            className="flex flex-col gap-1 h-auto py-2"
          >
            <MessageCircle className="h-4 w-4" />
            <span className="text-xs">Chat</span>
          </Button>
          <Button
            size="sm"
            variant={activeTab === "polls" ? "default" : "outline"}
            onClick={() => setActiveTab("polls")}
            className="flex flex-col gap-1 h-auto py-2"
          >
            <BarChart3 className="h-4 w-4" />
            <span className="text-xs">Polls</span>
          </Button>
        </div>
      </div>
    )
  }

  if (activeTab === "materials") {
    return (
      <div className="max-w-md mx-auto p-4 space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Button size="sm" variant="ghost" onClick={() => setActiveTab("classroom")}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h2 className="font-semibold">Course Materials</h2>
        </div>

        <div className="space-y-3">
          {slides.map((slide) => (
            <Card key={slide.id} className="cursor-pointer hover:bg-muted/50">
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-sm font-medium">{slide.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{slide.content}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      2.1 MB
                    </Badge>
                    <Button size="sm" variant="ghost">
                      <Download className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium">Complete Lesson Audio</h3>
                <p className="text-xs text-muted-foreground">Full 45-minute recording</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  8.5 MB
                </Badge>
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  <Download className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (activeTab === "chat") {
    return (
      <div className="max-w-md mx-auto p-4 space-y-4 h-screen flex flex-col">
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => setActiveTab("classroom")}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h2 className="font-semibold">Class Chat</h2>
          <Badge variant="outline" className="ml-auto">
            <Users className="h-3 w-3 mr-1" />
            24 online
          </Badge>
        </div>

        <ScrollArea className="flex-1">
          <div className="space-y-3">
            {chatMessages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.isTeacher ? "justify-start" : "justify-end"}`}>
                <div
                  className={`max-w-[80%] rounded-lg p-2 ${
                    msg.isTeacher ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                  }`}
                >
                  <div className="text-xs font-medium mb-1">{msg.sender}</div>
                  <div className="text-sm">{msg.message}</div>
                  <div className="text-xs opacity-70 mt-1">{msg.time}</div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="flex gap-2">
          <Input
            placeholder="Type your message..."
            value={chatMessage}
            onChange={(e) => setChatMessage(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
            className="flex-1"
          />
          <Button size="sm" onClick={sendMessage} className="bg-primary hover:bg-primary/90">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    )
  }

  if (activeTab === "polls") {
    return (
      <div className="max-w-md mx-auto p-4 space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Button size="sm" variant="ghost" onClick={() => setActiveTab("classroom")}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h2 className="font-semibold">Live Poll</h2>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">{pollQuestion.question}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {pollQuestion.options.map((option, index) => (
              <Button
                key={index}
                variant="outline"
                className="w-full justify-start text-left h-auto p-3 bg-transparent"
                onClick={() => {}}
              >
                <span className="font-medium mr-2">{String.fromCharCode(65 + index)}.</span>
                {option}
              </Button>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Poll Results</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>A. 4</span>
              <span>15%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-muted-foreground h-2 rounded-full w-[15%]"></div>
            </div>

            <div className="flex justify-between text-sm">
              <span>B. 5</span>
              <span>70%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-primary h-2 rounded-full w-[70%]"></div>
            </div>

            <div className="flex justify-between text-sm">
              <span>C. 6</span>
              <span>10%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-muted-foreground h-2 rounded-full w-[10%]"></div>
            </div>

            <div className="flex justify-between text-sm">
              <span>D. 7</span>
              <span>5%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-muted-foreground h-2 rounded-full w-[5%]"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return null
}
