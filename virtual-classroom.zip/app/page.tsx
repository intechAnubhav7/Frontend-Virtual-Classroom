import { VirtualClassroom } from "@/components/virtual-classroom"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <VirtualClassroom />
    </main>
  )
}
